from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm
from django.contrib.auth.decorators import permission_required

# User/views.py
from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm

@permission_required('can_access_dashboard')
def power_bi_dashboard(request):
    return render(request, 'User/index2.html')