from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('icu_chief', 'ICU Chief'),
        ('chief_medical_office', 'Chief of Medical Office'),
        ('health_inspector', 'Health Inspector'),
        ('prescription_doctor', 'Prescription Doctor'),
    ]
    role = models.CharField(max_length=50, choices=ROLE_CHOICES, default='icu_chief')

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"
